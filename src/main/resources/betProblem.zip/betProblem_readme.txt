Bet-Problem Project
===================

Overview
--------
This project implements an HTTP-based back-end service for managing betting offers and stakes. It includes functionalities for session management, stake posting, and retrieving high stakes for specific bet offers.

Technical Approach
------------------
- Session Management: Utilizes SessionService and SessionController to create and validate sessions. Sessions are valid for 10 minutes, using LocalDateTime for time tracking.
- Stake Posting: StakeService and StakeController handle stake submissions, processing only those with valid session keys. StakeDTO and StakeMapper facilitate data transfer.
- High Stakes Retrieval: The getHighStakes method in StakeService employs a HashMap to efficiently store and retrieve the top 20 unique customer stakes.

Key Features
------------
- Efficient data handling using HashMap for high stakes retrieval, ensuring quick access and uniqueness of data.
- Modular architecture with separate controllers for different functionalities.
- DTOs and entities separate database concerns from client-facing data structures.
- Comprehensive logging and error handling for robust application flow.

Conclusion
----------
This solution effectively meets the project's functional and nonfunctional requirements, focusing on efficiency, simplicity, and reliability. Future enhancements could include persistence implementation and expanded testing for performance optimization.
